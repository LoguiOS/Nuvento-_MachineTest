//
//  AppEntryView.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//
import SwiftUI

struct AppEntryView: View {
    @State private var isAuthenticated = false
    @State private var checked = false

    var body: some View {
        Group {
            if !checked {
                ProgressView()
            } else if isAuthenticated {
                HomeView()
            } else {
                LoginView()
            }
        }
        .onAppear {
            LoginManager.shared.silentLogin { success in
                DispatchQueue.main.async {
                    isAuthenticated = success
                    checked = true
                }
            }
        }
    }
}
#Preview {
    AppEntryView()
}
