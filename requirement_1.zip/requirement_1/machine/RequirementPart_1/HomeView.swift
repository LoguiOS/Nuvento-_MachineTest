//
//  HomeView.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//
import SwiftUI

struct HomeView: View {
    var body: some View {
        Text("Welcome 🎉")
            .font(.title)
    }
}
#Preview {
    HomeView()
}
