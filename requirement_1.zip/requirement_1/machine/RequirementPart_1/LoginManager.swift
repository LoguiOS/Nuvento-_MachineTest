//
//  LoginMaster.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//
import Foundation

final class LoginManager {
    static let shared = LoginManager()
    private let tokenKey = "oauth_token"
    private let service = "com.myapp.auth"

    private init() {}

    func login(
        username: String,
        password: String,
        completion: @escaping (Bool) -> Void
    ) {
        let url = URL(string: "https://oauth.com/oauth/token")!

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "grant_type": "password",
            "username": username,
            "password": password,
            "client_id": "CLIENT_ID",
            "client_secret": "CLIENT_SECRET"
        ]

        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard
                let data = data,
                let response = try? JSONDecoder().decode(TokenResponse.self, from: data)
            else {
                completion(false)
                return
            }
            self.cacheToken(response.accessToken)
            completion(true)

        }.resume()
    }
    func silentLogin(completion: @escaping (Bool) -> Void) {
        guard NetworkMonitor.shared.isConnected else {
            forceLogout()
            completion(false)
            return
        }
        guard let token = getCachedToken() else {
            completion(false)
            return
        }
        var request = URLRequest(url: URL(string: "https://example.com/oauth/validate")!)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        URLSession.shared.dataTask(with: request) { _, response, _ in
            let isValid = (response as? HTTPURLResponse)?.statusCode == 200
            completion(isValid)
        }.resume()
    }
    private func cacheToken(_ token: String) {
        let data = Data(token.utf8)
        KeychainHelper.shared.save(data, service: service, account: tokenKey)
    }
    private func getCachedToken() -> String? {
        guard let data = KeychainHelper.shared.read(service: service, account: tokenKey)
        else { return nil }
        return String(decoding: data, as: UTF8.self)
    }
    func forceLogout() {
        KeychainHelper.shared.delete(service: service, account: tokenKey)
    }
}

struct TokenResponse: Codable {
    let accessToken: String
    
    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
    }
}

