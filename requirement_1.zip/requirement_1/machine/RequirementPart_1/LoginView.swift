//
//  LoginView.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//

import SwiftUI

struct LoginView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var path = NavigationPath()
    
    var body: some View {
        NavigationStack(path: $path) {
            VStack(spacing: 20) {
                Text("Login")
                    .font(.largeTitle)
                TextField("Username", text: $username)
                    .textFieldStyle(.roundedBorder)
                SecureField("Password", text: $password)
                    .textFieldStyle(.roundedBorder)
                    Button("Login") {
                        LoginManager.shared.login(
                            username: username,
                            password: password
                        ) { success in
                            DispatchQueue.main.async {
                                path.append("Home view")
                            }
                        }
                    }
                    .navigationDestination(for: String.self) { value in
                        HomeView()
                    }
                }
            }
            .padding()
    }
}
#Preview {
    LoginView()
}
