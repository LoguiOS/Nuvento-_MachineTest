//
//  Requirement_OAuth.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//

import Foundation
import SwiftUI
import Combine

struct Requirement_OAuth: View{
    var text: String = ""
    
    var body: some View {
        Text("Requirement_OAuth")
    }
}

#Preview {
    Requirement_OAuth()
}
