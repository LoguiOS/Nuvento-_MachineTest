//
//  ContentView.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        Text("Hello, World!")
    }
}


#Preview {
    ContentView()
}
