//
//  Persistence.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//
import CoreData

final class PersistenceController {
    static let shared = PersistenceController()

    let container: NSPersistentContainer

    init() {
        container = NSPersistentContainer(name: "machine")
        container.loadPersistentStores { _, error in
            if let error = error {
                fatalError("CoreData error \(error)")
            }
        }
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }
}
