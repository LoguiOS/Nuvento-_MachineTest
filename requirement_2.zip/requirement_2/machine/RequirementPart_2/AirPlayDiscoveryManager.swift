//
//  AirPlayDiscoveryManager.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.

import Foundation
import Combine
import SwiftUI
import Network
import CoreData

struct AirPlayDevice: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let ipAddress: String
    var status: DeviceStatus
}

enum DeviceStatus: String {
    case reachable = "Reachable"
    case unreachable = "Un-Reachable"
}

final class AirPlayDiscoveryManager: NSObject, ObservableObject {
    
    @Published var devices: [AirPlayDevice] = []
    
    private let browser = NetServiceBrowser()
    private var services: [NetService] = []
    
    override init() {
        super.init()
        browser.delegate = self
    }
    
    func startDiscovery() {
        devices.removeAll()
        services.removeAll()
        browser.searchForServices(ofType: "_airplay._tcp.", inDomain: "")
    }
    
    func stopDiscovery() {
        browser.stop()
    }
}

extension AirPlayDiscoveryManager: NetServiceBrowserDelegate {
    
    func netServiceBrowser(_ browser: NetServiceBrowser,
                           didFind service: NetService,
                           moreComing: Bool) {
        
        service.delegate = self
        services.append(service)
        service.resolve(withTimeout: 5)
    }
    
    func netServiceBrowser(_ browser: NetServiceBrowser,
                           didRemove service: NetService,
                           moreComing: Bool) {
        
        DispatchQueue.main.async {
            self.devices.removeAll { $0.name == service.name }
        }
    }
}

extension AirPlayDiscoveryManager: NetServiceDelegate {
    
    func netServiceDidResolveAddress(_ sender: NetService) {
        
        guard let addresses = sender.addresses else { return }
        
        for addressData in addresses {
            var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            let result = addressData.withUnsafeBytes { pointer -> Int32 in
                let sockaddrPtr = pointer.bindMemory(to: sockaddr.self)
                return getnameinfo(
                    sockaddrPtr.baseAddress,
                    socklen_t(pointer.count),
                    &hostname,
                    socklen_t(hostname.count),
                    nil,
                    0,
                    NI_NUMERICHOST
                )
            }
            
            if result == 0 {
                let ip = String(cString: hostname)
                checkReachability(ip: ip, name: sender.name)
                break
            }
        }
    }
}

extension AirPlayDiscoveryManager {
    
    private func checkReachability(ip: String, name: String) {
        
        let endpoint = NWEndpoint.Host(ip)
        let connection = NWConnection(host: endpoint, port: 7000, using: .tcp)
        
        connection.stateUpdateHandler = { state in
            DispatchQueue.main.async {
                let status: DeviceStatus = (state == .ready) ? .reachable : .unreachable
                
                let device = AirPlayDevice(
                    name: name,
                    ipAddress: ip,
                    status: status
                )
                
                if let index = self.devices.firstIndex(where: { $0.name == name }) {
                    self.devices[index] = device
                } else {
                    self.devices.append(device)
                }
            }
            connection.cancel()
        }
        
        connection.start(queue: .global())
    }
}

struct AirPlayListView: View {
    
    @StateObject private var manager = AirPlayDiscoveryManager()
    
    var body: some View {
        NavigationView {
            List(manager.devices) { device in
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(device.name)
                            .font(.headline)
                        
                        Text(device.ipAddress)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    
                    Spacer()
                    
                    Text(device.status.rawValue)
                        .font(.caption)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(
                            device.status == .reachable ? Color.green.opacity(0.2)
                            : Color.red.opacity(0.2)
                        )
                        .foregroundColor(
                            device.status == .reachable ? .green : .red
                        )
                        .cornerRadius(8)
                }
            }
            .navigationTitle("AirPlay Devices")
            .onAppear {
                manager.startDiscovery()
            }
            .onDisappear {
                manager.stopDiscovery()
            }
        }
    }
}

#Preview {
    AirPlayListView()
}
