//
//  machineApp.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//

import SwiftUI
import CoreData

@main
struct machineApp: App {

    var body: some Scene {
        WindowGroup {
            AirPlayListView()
        }
    }
}
