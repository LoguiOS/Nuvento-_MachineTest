//
//  IPListView.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//
import SwiftUI

struct IPListView: View {

    @StateObject private var viewModel = IPViewModel()

    var body: some View {
        NavigationStack {
            List {
                if let ip = viewModel.ipAddress {
                    NavigationLink(value: ip) {
                        VStack(alignment: .leading) {
                            Text("Public IP")
                                .font(.caption)
                                .foregroundColor(.gray)
                            Text(ip)
                                .font(.headline)
                        }
                    }
                }
            }
            .navigationTitle("IP Address")
            .navigationDestination(for: String.self) { ip in
                IPDetailView(ip: ip)
            }
            .overlay {
                if viewModel.isLoading {
                    ProgressView()
                }
            }
            .onAppear {
                viewModel.loadIP()
            }
        }
    }
}

struct IPDetailView: View {

    let ip: String
    @State private var detail: IPDetail?
    @State private var isLoading = true

    private let service = IPService()

    var body: some View {
        List {
            if let detail = detail {
                
                Section("Location") {
                    infoRow("City", detail.city)
                    infoRow("Region", detail.region)
                    infoRow("Country", detail.country)
                    infoRow("Coordinates", detail.loc)
                }

                Section("Network") {
                    infoRow("IP", detail.ip)
                    infoRow("Organization", detail.org)
                    infoRow("Timezone", detail.timezone)
                }
            }
        }
        .navigationTitle("IP Details")
        .overlay {
            if isLoading {
                ProgressView()
            }
        }
        .onAppear {
            loadDetails()
        }
    }

    private func loadDetails() {
        service.fetchIPDetails(ip: ip) { result in
            DispatchQueue.main.async {
                isLoading = false
                if case .success(let data) = result {
                    detail = data
                }
            }
        }
    }

    @ViewBuilder
    private func infoRow(_ title: String, _ value: String?) -> some View {
        HStack {
            Text(title)
            Spacer()
            Text(value ?? "-")
                .foregroundColor(.gray)
        }
    }
}
#Preview {
    IPListView()
}
