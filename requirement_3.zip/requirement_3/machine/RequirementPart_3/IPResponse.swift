//
//  Untitled.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//

struct IPResponse: Codable {
    let ip: String
}

struct IPDetail: Codable {
    let ip: String?
    let city: String?
    let region: String?
    let country: String?
    let loc: String?
    let org: String?
    let timezone: String?
}
