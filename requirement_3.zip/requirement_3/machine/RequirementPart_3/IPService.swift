//
//  Untitled.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//
import Foundation

final class IPService {

    // Get Public IP
    func fetchPublicIP(completion: @escaping (Result<String, Error>) -> Void) {
        let url = URL(string: "https://api.ipify.org?format=json")!

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            do {
                let result = try JSONDecoder().decode(IPResponse.self, from: data!)
                completion(.success(result.ip))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }

    // Get IP Details
    func fetchIPDetails(ip: String, completion: @escaping (Result<IPDetail, Error>) -> Void) {
        let url = URL(string: "https://ipinfo.io/\(ip)/geo")!

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            do {
                let details = try JSONDecoder().decode(IPDetail.self, from: data!)
                completion(.success(details))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
}
