//
//  Untitled.swift
//  machine
//
//  Created by 3DOTS Dev on 03/02/26.
//
import Combine
import SwiftUI
import Foundation

@MainActor
final class IPViewModel: ObservableObject {

    @Published var ipAddress: String?
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let service = IPService()

    func loadIP() {
        isLoading = true

        service.fetchPublicIP { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let ip):
                    self?.ipAddress = ip
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
}
